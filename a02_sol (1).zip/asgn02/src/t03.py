"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Safaa Bedawi
ID:     11111111
Email:  sbedawi@wlu.ca
__updated__ = "2020-04-20"
------------------------------------------------------------------------
"""
#constants
SIX_PLACE = 1000000
FOURTH_PLACE = 10000
SECOND_PLACE = 100
# Inputs
date = int(input("Enter a date in the format MMDDYYYY: "))

# Calculations
month = date // SIX_PLACE
day = date // FOURTH_PLACE % SECOND_PLACE
year = date % FOURTH_PLACE

# Output
print()
print("{:02d}/{:02d}/{:04d}".format(day, month, year))

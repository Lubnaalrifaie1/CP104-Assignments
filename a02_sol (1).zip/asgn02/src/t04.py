"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Safaa Bedawi
ID:     11111111
Email:  sbedawi@wlu.ca
__updated__ = "2020-04-20"
------------------------------------------------------------------------
"""
# Inputs
flyers = int(input("Number of flyers: "))
volunteers = int(input("Number of volunteers: "))

# Calculations
flyers_per_volunteer = flyers // volunteers
flyers_left = flyers % volunteers

# Output
print()
print("Each volunteer will receive {} flyer/s".format(flyers_per_volunteer))
print("flyers that won't be distributed: {:d}".format(flyers_left))

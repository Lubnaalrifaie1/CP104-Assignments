"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Safaa Bedawi
ID:     11111111
Email:  sbedawi@wlu.ca
__updated__ = "2020-04-20"
------------------------------------------------------------------------
"""
# Constants
MIDTERM_PORTION = 0.20
EXAM_PORTION = 0.40

# Inputs
midterm_mark = float(input("Midterm mark (%): "))
final_exam_mark = float(input("Final exam mark (%): "))

# Calculations
total = int((MIDTERM_PORTION + EXAM_PORTION) * 100)
out_of = MIDTERM_PORTION * midterm_mark + EXAM_PORTION * final_exam_mark
weighted_exam = out_of / (MIDTERM_PORTION + EXAM_PORTION)

# Outputs
print()
print("Your weighted exam average is: {:.1f}. The passing mark of the weighted exam average is 50%".format(
    weighted_exam))

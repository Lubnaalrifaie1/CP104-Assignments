"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Safaa Bedawi
ID:     11111111
Email:  sbedawi@wlu.ca
__updated__ = "2020-04-20"
------------------------------------------------------------------------
"""
# Constants
ANNUAL_PROFIT = 0.17

# Inputs
sales = float(input("Enter the total amount of sales: $"))
rate = ANNUAL_PROFIT * 100

# Calculations
profit = sales * ANNUAL_PROFIT

# Outputs
print()
print("Projected Profit Report")
print("--------------------------")
print("Total sales:   $ {:.2f}".format(sales))
print("Annual profit: % {:.0f}".format(rate))
print("--------------------------")
print("Profit:        $ {:.2f}".format(profit))

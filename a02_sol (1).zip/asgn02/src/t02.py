"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Safaa Bedawi
ID:     11111111
Email:  sbedawi@wlu.ca
__updated__ = "2020-04-20"
------------------------------------------------------------------------
"""
# Inputs
date = int(input("Enter a date in the format MMDDYYYY: "))

# Calculations
month = date // 1000000
day = date // 10000 % 100
year = date % 10000

# Output
print()
print("{:02d}/{:02d}/{:04d}".format(day, month, year))

"""
-------------------------------------------------------
Assignment 7, Task 3
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-03-22"
-------------------------------------------------------
"""
# Imports
from functions import frequent

string = input("Enter a string: ")
most_freq = frequent(string)
print("Most frequent characters: {}".format(most_freq))

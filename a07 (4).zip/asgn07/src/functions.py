"""
-------------------------------------------------------
Assignment 7 Functions
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-03-23"
-------------------------------------------------------
"""


def vowels_sc(my_str):
    """
    -------------------------------------------------------
    Extracts and flips the case of all vowels in a string.
    Use: vowel_string = vowels_sc(my_str)
    -------------------------------------------------------
    Parameters:
        my_str - a string (str)
    Returns:
        vowel_string - all vowels in my_str with case flipped (str)
    -------------------------------------------------------
    """
    UPPER_VOWELS = "AEIOU"
    LOWER_VOWELS = "aeiou"
    vowel_string = ""

    for char in my_str:
        if char in UPPER_VOWELS:
            vowel_string += char.lower()
        elif char in LOWER_VOWELS:
            vowel_string += char.upper()

    return vowel_string


def str_digit_sum(my_str):
    """
    -------------------------------------------------------
    Sums all the digits in my_str
    Use: total = str_digit_sum(my_str)
    -------------------------------------------------------
    Parameters:
        my_str - string that has single-digit numbers (str)
    Returns:
        total - sum of all the single digit number (integer >= 0)
    -------------------------------------------------------
    """
    total = 0

    for char in my_str:
        total += int(char)
    return total


def frequent(my_str):
    """
    -------------------------------------------------------
    Finds the first most frequently used character in my_str.
    Use: found = frequent(my_str)
    -------------------------------------------------------
    Parameters:
        my_str - the parameter string (str)
    Returns:
        found - the first most frequent character in my_str
            (str, len == 1)
    -------------------------------------------------------
    """
    chars = []
    counts = []

    for char in my_str:
        # Process the string and update the lists of characters
        # and counts of characters
        if char in chars:
            i = chars.index(char)
            counts[i] += 1
        else:
            chars.append(char)
            counts.append(1)

    # Find the first character with the maximum count
    n = max(counts)
    i = counts.index(n)
    found = chars[i]
    return found


def proper_spaces(my_str):
    """
    -------------------------------------------------------
    Create a new string with added space between words
    Use: new_str = proper_spaces(my_str)
    -------------------------------------------------------
    Parameters:
        my_str - string that represents a sentence in which all the
            words are run together (no spaces), but the first character
            of each word is uppercase. my_str should has at least one
            character (str)
    Returns:
        new_str - new string in which the words are separated
            by spaces and only the first word starts with
            an uppercase character (str)
    -------------------------------------------------------
    """
    new_str = my_str[0]

    for char in my_str[1:]:
        if char.isupper():
            new_str += " " + char.lower()
        else:
            new_str += char
    return new_str


def chain(my_list):
    """
    -------------------------------------------------------
    Determines if a list of strings is a word chain.
    Use: word_chain = chain(my_list)
    -------------------------------------------------------
    Parameters:
        my_list - a of strings (list of str, len > 1)
    Returns:
        word_chain - True if my_list is a word chain,
            False otherwise (boolean)
    -------------------------------------------------------
    """
    word_chain = True

    n = len(my_list)
    i = 1

    while word_chain and i < n:
        if my_list[i - 1][-1] != my_list[i][0]:
            word_chain = False
        else:
            i += 1
    return word_chain

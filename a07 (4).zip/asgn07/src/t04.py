"""
-------------------------------------------------------
Assignment 7, Task 4
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-03-22"
-------------------------------------------------------
"""
# Imports
from functions import proper_spaces

string = input("Enter a string: ")
spaced = proper_spaces(string)
print()
print("Result: {}".format(spaced))

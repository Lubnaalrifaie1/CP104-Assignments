"""
-------------------------------------------------------
Assignment 7, Task 5
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-03-22"
-------------------------------------------------------
"""
# Imports
from functions import chain

words = ['camel', 'leopard', 'dog', 'giraffe', 'elephant']
wc = chain(words)
print("Words: {}".format(words))
print("Word Chain: {}".format(wc))
print()
words = ['not', 'a', 'word', 'chain']
wc = chain(words)
print("Words: {}".format(words))
print("Word Chain: {}".format(wc))

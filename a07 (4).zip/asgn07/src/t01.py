"""
-------------------------------------------------------
Assignment 7, Task 1
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-03-22"
-------------------------------------------------------
"""
from functions import vowels_sc

string = input("Enter a string: ")
vowel_string = vowels_sc(string)
print("Flipped vowels: {}".format(vowel_string))

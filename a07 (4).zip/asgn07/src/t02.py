"""
-------------------------------------------------------
Assignment 7, Task 2
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2020-11-16"
-------------------------------------------------------
"""
# Imports
from functions import str_digit_sum

string = input("Enter a string of single-digit numbers: ")
total = str_digit_sum(string)
print()
print("Total: {}".format(total))

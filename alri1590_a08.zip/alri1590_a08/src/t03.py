"""
-------------------------------------------------------
[alri1590_a08]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-04-04"
-------------------------------------------------------
"""
from functions import file_stats


filename = input("Enter your file name: ")

try:
    file_handle = open(filename, "r")
except FileNotFoundError:
    print("Error: File not found")
else:
    ucount, lcount, dcount, wcount = file_stats(file_handle)
    file_handle.close()
    print(ucount, lcount, dcount, wcount)
    file_handle = open("out_t03.txt", "w")
    file_handle.write(f"{ucount}, {lcount}, {dcount}, {wcount}")
    file_handle.close()
    print(f"{filename} stats written to out_t03.txt file")

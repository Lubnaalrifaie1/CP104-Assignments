"""
-------------------------------------------------------
[alri1590_a08]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-04-03"
-------------------------------------------------------
"""
from functions import median


file_name = input("Enter file name: ")

median = median(file_name)
print("Median is:", median)

outfile = open("out_t02.txt", "w")
outfile.write("Median is: ")
outfile.write(str(median))

print("Data written into out_t02.txt")
outfile.close()

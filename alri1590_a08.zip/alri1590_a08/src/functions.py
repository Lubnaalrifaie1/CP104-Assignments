"""
-------------------------------------------------------
[alri1590_a08]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-04-04"
-------------------------------------------------------
"""


def total(file_handle):
    """
    -------------------------------------------------------
    Extracts numbers from a file. Only number surrounded by spaces
    are counted - numbers that are parts of words are ignored.
    Use: numbers, total = total_nums(file_handle)
    -------------------------------------------------------
    Parameters:
        file_handle - a file already open for reading (file handle)
    Returns:
        numbers - a list of integers from file_handle (list of int)
        total - total of value in numbers (int)
    -------------------------------------------------------
    """
    numbers = []
    total = 0
    for line in file_handle:
        words = line.split()
        for word in words:
            if word.isdigit():
                number = int(word)
                numbers.append(number)
                total += number
    return numbers, total


def median(file_handle):
    """
    -------------------------------------------------------
    Extracts numbers from a file and calculates their median value.
    Use: median = locate_median(file_handle)
    -------------------------------------------------------
    Parameters:
        file_handle - a file already open for reading (file handle)
    Returns:
        m - median of the values in file_handle (float)
    -------------------------------------------------------
    """
    infile = open(file_handle, "r")
    numbers = []
    for line in infile.readlines():
        line = line.rstrip()
        words = line.split(",")
        for word in words:
            numbers.append(int(word))

    numbers.sort()
    mid = len(numbers) // 2
    if len(numbers) % 2 == 0:
        m = (numbers[mid - 1] + numbers[mid]) / 2
    else:
        m = numbers[mid]
    return m


def file_stats(file_handle):
    """
    -------------------------------------------------------
    Evaluates the contents of a file.
    Use: ucount, lcount, dcount, wcount = file_analysis(file_handle)
    -------------------------------------------------------
    Parameters:
        file_handle - a file already open for reading (file handle)
    Returns:
        ucount - The number of uppercase letters in the file (int)
        lcount - The number of lowercase letters in the file (int)
        dcount - The number of digits in the file (int)
        wcount - The number of whitespace characters in the file (int)
    -------------------------------------------------------
    """
    ucount = 0
    lcount = 0
    dcount = 0
    wcount = 0
    for line in file_handle:
        for char in line:
            if char.isdigit():
                dcount += 1
            elif char.isspace():
                wcount += 1
            elif char.isupper():
                ucount += 1
            elif char.islower():
                lcount += 1
    return ucount, lcount, dcount, wcount


def valid(string):
    """
    -------------------------------------------------------
    Determines if a string is a good serial number. Good serial
     numbers are of the form 'SN/nnnn-nnn', where 'n' is a digit.
     Use: is_valid = valid(sn)
     -------------------------------------------------------
     Parameters:
        string - a possible serial number (str)
     Returns:
        is_valid - True if sn is a good serial number,
            False otherwise (boolean)
    -------------------------------------------------------
    """
    if len(string) == 11 and string.startswith('SN/') and string[7] == '-' and \
            string[3:7].isdigit() and string[8:].isdigit():
        is_valid = True
    else:
        is_valid = False
    return is_valid


def valid_file(in_handle, out_valid, out_invalid):
    """
     -------------------------------------------------------
     Evaluates serial numbers from a file. Writes valid serial
     numbers to good_sns, and invalid serial numbers to bad_sns.
     Use: valid_file(in_handle, out_valid, out_invalid)
     -------------------------------------------------------
     Parameters:
         in_handle - a file already open for reading (file handle)
         out_valid - a file already open for writing (file handle)
         out_invalid - a file already open for writing (file handle)
     Returns:
         None
     -------------------------------------------------------
     """
    for line in in_handle:
        line = line.strip()
        if valid(line):
            print(line, file=out_valid)
        else:
            print(line, file=out_invalid)
    return

"""
-------------------------------------------------------
[alri1590_a08]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-04-04"
-------------------------------------------------------
"""
from functions import total


filename = input('Enter your file name:  ')

with open(filename, 'r') as fh:
    numbers, tot = total(fh)
    print("Numbers: {}, Total: {}".format(numbers, tot))
with open('out_t01.txt', 'w') as f:
    f.write(str(numbers))

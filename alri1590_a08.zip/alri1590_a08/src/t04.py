"""
-------------------------------------------------------
[alri1590_a08]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-04-04"
-------------------------------------------------------
"""
from functions import valid, valid_file

if __name__ == "__main__":
    input_txt = input("Enter your file name: ")
    valid_txt = "out_t04_valid.txt"
    invalid_txt = "out_t04_invalid.txt"
    with open(input_txt, 'r') as inp, open(valid_txt, 'w+') as val, open(invalid_txt, 'w+') as inval:
        valid_file(inp, val, inval)

"""
-------------------------------------------------------
Assignment 3, task 3
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-02-22"
-------------------------------------------------------
"""
# Imports
from functions import date_convert

# Inputs
date_number = int(input("Enter a date in the format MMDDYYYY: "))

# Calculations
day, month, year = date_convert(date_number)

# Outputs
print()
print("{:02d}/{:02d}/{:4d}".format(day, month, year))

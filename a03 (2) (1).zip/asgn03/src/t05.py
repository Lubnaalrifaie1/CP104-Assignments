"""
-------------------------------------------------------
Assignment 3, Task 5
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-02-22"
-------------------------------------------------------
"""
# Imports
from functions import math_quiz

math_quiz()

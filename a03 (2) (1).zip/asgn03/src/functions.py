"""
-------------------------------------------------------
Assignment 3 Functions
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-02-18"
-------------------------------------------------------
"""
# Imports
from random import randint

# Constants: falling_distance
GRAVITY_ACCEL = 9.8  # m/s^2

# Constants: calorie_calculator
FAT_CONVERT = 9
CARB_CONVERT = 4

# Constants: convert_seconds
SECONDS_PER_MINUTE = 60
SECONDS_PER_HOUR = SECONDS_PER_MINUTE * 60
SECONDS_PER_DAY = SECONDS_PER_HOUR * 24

# Constants: math_quiz
MAX_VALUE = 999


def falling_distance(falling_time):
    """
    -------------------------------------------------------
    Calculates distance an object has fallen due to gravity given
    the time it is fallen.
    Use: distance = falling_distance(falling_time)
    -------------------------------------------------------
    Parameters:
        falling_time - time object has fallen in seconds (float >= 0)
    Returns:
        distance - distance object has fallen in m (float)
    -------------------------------------------------------
    """
    distance = 0.5 * GRAVITY_ACCEL * falling_time**2
    return distance


def calorie_calc(grams_fat, grams_carb):
    """
    -------------------------------------------------------
    Calculates calories due to fats and carbs given
    grams of fats and carbs.
    Use: fat_calories, carb_calories = calorie_calculator(grams_fat, grams_carb)
    -------------------------------------------------------
    Parameters:
        grams_fat - grams of fat (int >= 0)
        grams_carb - grams of carbs (int >= 0)
    Returns:
        fat_calories - calories due to fat (int)
        carb_calories - calories due to carbs (int)
    -------------------------------------------------------
    """
    fat_calories = grams_fat * FAT_CONVERT
    carb_calories = grams_carb * CARB_CONVERT
    return fat_calories, carb_calories


def date_convert(date_int):
    """
    -------------------------------------------------------
    Converts date_int into days, month and year
    use: day, month, year = date_convert(date_int)
    -------------------------------------------------------
    Parameters:
        date_int – (int > 0)
    Returns:
        day: the day in the month in date_int (int >= 0)
        month: the month in date_int (int >=0)
        year: the years in date_int (int >=0)
    -------------------------------------------------------
    """
    year = date_int % 10000
    date_int = date_int // 10000
    days = date_int % 100
    month = date_int // 100
    return days, month, year


def convert_sec(num_sec):
    """
    -------------------------------------------------------
    Converts num_sec into days, hours, minutes and seconds
    Use: days, hours, minutes, seconds = convert_sec(num_sec)
    -------------------------------------------------------
    Parameters:
        initial_seconds - time elapsed (int >= 0)
    Returns:
        days - number of days in num_sec (int)
        hours - number of hours in num_sec (int)
        minutes - number of minutes in num_sec (int)
        seconds - number of seconds in num_sec (int)
    -------------------------------------------------------
    """
    # Calculate days.
    days = int(num_sec // SECONDS_PER_DAY)
    seconds = num_sec % SECONDS_PER_DAY
    # Calculate hours with seconds left.
    hours = int(seconds // SECONDS_PER_HOUR)
    seconds = seconds % SECONDS_PER_HOUR
    # Calculate minutes with seconds left.
    minutes = int(seconds // SECONDS_PER_MINUTE)
    seconds = seconds % SECONDS_PER_MINUTE
    return days, hours, minutes, seconds


def math_quiz():
    """
    -------------------------------------------------------
    Performs a simple math quiz.
    Randomly generates two numbers between 0 and MAX_VALUE
    and asks the user their total. Prints congratulations
    if answer is correct, and correct answer otherwise.
    Use: math_quiz()
    -------------------------------------------------------
    Returns
        None
    -------------------------------------------------------
    """
    n1 = randint(0, MAX_VALUE)
    n2 = randint(0, MAX_VALUE)
    total = n1 + n2
    print('  {0:3d}'.format(n1))
    print('+ {0:3d}'.format(n2))
    print()

    user_answer = int(input("Please enter your answer: "))

    print()
    print("Your answer: {}, it should be: {}".format(user_answer, total))

    return

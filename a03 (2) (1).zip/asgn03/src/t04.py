"""
-------------------------------------------------------
Assignment 3, Task 4
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-02-22"
-------------------------------------------------------
"""
# Imports
from functions import convert_sec

# Inputs
ns = int(input("Enter number of seconds: "))

# Calculations
ds, hs, ms, ss = convert_sec(ns)
# Outputs
print("There are {} days, {} hours, {} minutes, and {} seconds in {} seconds".format(
    ds, hs, ms, ss, ns))

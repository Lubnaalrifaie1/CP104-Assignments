"""
-------------------------------------------------------
Assignment 3, Task 1
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-02-22"
-------------------------------------------------------
"""
# Imports
from functions import falling_distance

# Inputs
time = int(input("Enter the time (in secs): "))

# Calculations
distance = falling_distance(time)

# Outputs
print("The Object has falling {:.2f} meters in {:d} seconds.".format(
    distance, time))

"""
-------------------------------------------------------
Assignment 3, Task 2
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-02-22"
-------------------------------------------------------
"""
# Imports
from functions import calorie_calc

# Inputs
fat_gm = int(input("Enter the fat grams consumed: "))
carb_gm = int(input("Enter the carbohydrate grams consumed: "))

# Calculations
fat_cal, carb_cal = calorie_calc(fat_gm, carb_gm)
total_cal = fat_cal + carb_cal

# Outputs
print()
print("Fat calories:   {:4d}".format(fat_cal))
print("Carb calories:  {:4d}".format(carb_cal))
print("Total calories: {:4d}".format(total_cal))

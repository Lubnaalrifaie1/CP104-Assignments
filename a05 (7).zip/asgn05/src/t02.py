"""
-------------------------------------------------------
Assignment 5 Task 2
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-03-08"
-------------------------------------------------------
"""
# Imports
from functions import prime

# Inputs
num = int(input("Enter a positive integer number: "))

# Outputs
if num >= 0:
    is_prime = prime(num)

    if is_prime:
        print("{} is a prime number".format(num))
    else:
        print("{} is not a prime number".format(num))
else:
    print("Error: you entered a negative number")

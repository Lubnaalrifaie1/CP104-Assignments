"""
-------------------------------------------------------
Assignment 5 Task 4
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = '2021-03-08'
-------------------------------------------------------
"""
# Imports
from functions import winner

rc, gc = winner()

print("Number of red entered: {}".format(rc))
print("Number of green entered: {}".format(gc))

if rc > gc:
    print("red team wins!!!")
elif gc > rc:
    print("green team wins!!!")
else:
    print("tie")

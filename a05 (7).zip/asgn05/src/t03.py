"""
-------------------------------------------------------
Assignment 5 Task 3
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-03-08"
-------------------------------------------------------
"""
# Imports
from functions import pattern

# Inputs
num = int(input("Enter number of rows: "))

while num < 0:
    print("Error: number of rows must be positive")
    num = int(input("Enter number of rows: "))

# Outputs
print()
pattern(num)

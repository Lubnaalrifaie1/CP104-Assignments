"""
-------------------------------------------------------
Assignment 5 Functions
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-03-08"
-------------------------------------------------------
"""
# imports
from math import sqrt


def fact(num):
    """
    -------------------------------------------------------
    Calculates and returns the factorial of num.
    Use: product = fact(num)
    -------------------------------------------------------
    Parameters:
        num - number to factorial (int > 0)
    Returns:
        product - num! (int)
    ------------------------------------------------------
    """
    product = 1

    for i in range(2, num + 1):
        product *= i

    return product


def prime(n):
    """
    -------------------------------------------------------
    Determines if n is a prime number.
    Use: is_prime = prime(n)
    -------------------------------------------------------
    Parameters:
        n - an integer (int)
    Returns:
        is_prime - True if n is prime, False otherwise (bool)
    ------------------------------------------------------
    """
    stop = int(sqrt(n) + 1)
    is_prime = True
    i = 2

    while is_prime and i < stop:
        if n % i == 0:
            is_prime = False
        i += 1
    return is_prime


def pattern(num_rows):
    """
    -------------------------------------------------------
    Prints a hollow triangle of num_lines characters high.
    Use: pattern(num_rows)
    -------------------------------------------------------
    Parameters:
        num_rows - number of rows to print (int > 0)
    Returns:
        None
    ------------------------------------------------------
    """
    for i in range(num_rows):
        print("#", end="")

        for _ in range(i):
            print(" ", end="")
        print("#")
    return


def winner():
    """
    -------------------------------------------------------
    Counts the number of times the strings 'red' and 'green'
    are entered by a user.
    Use: rcount, gcount = winner()
    -------------------------------------------------------
    Returns:
        rcount - number of times 'red' was entered (int)
        gcount - number of times 'green' was entered (int)
    -------------------------------------------------------
    """
    red_count = 0
    green_count = 0
    string = input('Enter the winning team: ')

    while string != "":
        # Convert to lower case for consistency
        string = string.lower()

        if string == 'red':
            red_count += 1
        elif string == 'green':
            green_count += 1
        string = input('Enter the winning team: ')

    return red_count, green_count

"""
-------------------------------------------------------
Assignment 5 Task 1
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-03-08"
-------------------------------------------------------
"""
# Imports
from functions import fact

# Inputs
num = int(input("Enter a positive number: "))

# Outputs
if num >= 0:
    product = fact(num)
    print("{}! = {}".format(num, product))
else:
    print("Error: you entered a negative number")

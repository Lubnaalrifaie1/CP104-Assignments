"""
-------------------------------------------------------
Assignment 4, Task 2
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-02-22"
-------------------------------------------------------
"""
# Imports
from functions import avg_lowest

# Inputs
v1 = int(input("Please enter your first number: "))
v2 = int(input("Please enter your second number: "))
v3 = int(input("Please enter your third number: "))

# Calculations
average = avg_lowest(v1, v2, v3)

# Outputs
print()
print("The average of the two smaller value is: {}".format(average))

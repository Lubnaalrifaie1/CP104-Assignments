"""
-------------------------------------------------------
Assignment 4, Task 1
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-02-21"
-------------------------------------------------------
"""
# Imports
from functions import conv_num

# Inputs
di = int(input("Please enter a number between 1 and 7: "))

# Calculations
day_name = conv_num(di)

# Outputs
print()
print("Number {} corresponds to {}.".format(di, day_name))

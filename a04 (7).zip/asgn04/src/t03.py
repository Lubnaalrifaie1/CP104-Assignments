"""
-------------------------------------------------------
Assignment 4, Task 3
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-02-21"
-------------------------------------------------------
"""
# Imports
from functions import pocket

# Inputs
number = int(input("Enter a pocket number: "))

# Calculations
col = pocket(number)

# Outputs
print("The selected pocket is {}.".format(col))

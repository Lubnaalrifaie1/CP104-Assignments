"""
-------------------------------------------------------
Assignment 4, Task 5
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-02-21"
-------------------------------------------------------
"""
# Imports
from functions import perfect_square

# Inputs
n = int(input("Enter a positive number: "))

# Calculations
squares = perfect_square(n)

# Outputs
print("Perfect squares below {} are: {}".format(n, squares))

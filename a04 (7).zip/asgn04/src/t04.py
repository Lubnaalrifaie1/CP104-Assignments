"""
-------------------------------------------------------
Assignment 4, Task 4
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-02-21"
-------------------------------------------------------
"""
# Imports
from functions import mix

# Inputs
c1 = input("Enter a first colour: ")
c2 = input("Enter a second colour: ")

# Calculations
mc = mix(c1, c2)

# Outputs
print("The mixed colour is {}.".format(mc))

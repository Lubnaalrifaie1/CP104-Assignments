"""
-------------------------------------------------------
Assignment 4 Functions
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-02-22"
-------------------------------------------------------
"""


def conv_num(day_int):
    """
    -------------------------------------------------------
    Returns the name of a day of the week given an integer day number.
    Returns an error message if the number is not valid.
    Use: day = conv_num(day_int)
    -------------------------------------------------------
    Parameters:
        day_int - day number (1 <= int <= 7)
    Returns:
        day - name of a day of the week (str)
    ------------------------------------------------------
    """
    if day_int == 1:
        day = "Monday"
    elif day_int == 2:
        day = "Tuesday"
    elif day_int == 3:
        day = "Wednesday"
    elif day_int == 4:
        day = "Thursday"
    elif day_int == 5:
        day = "Friday"
    elif day_int == 6:
        day = "Saturday"
    elif day_int == 7:
        day = "Sunday"
    else:
        day = "Error"
    return day


def avg_lowest(v1, v2, v3):
    """
    -------------------------------------------------------
    Returns the average of the two smallest values of v1, v2,
    and v3.
    Use: avg = avg_lowest(v1, v2, v3)
    -------------------------------------------------------
    Parameters:
        v1 - a number (float)
        v2 - a number (float)
        v3 - a number (float)
    Returns:
        avg - the average of the two smallest values of
            v1, v2, and v3 (float)
    ------------------------------------------------------
    Possible sets of smallest values:
    v1, v2 or v2, v1
    v1, v3 or v3, v1
    v2, v3 or v3, v2
    """
    if (v1 <= v2 and v2 <= v3) or (v2 <= v1 and v1 <= v3):
        s1 = v1
        s2 = v2
    elif (v2 <= v3 and v3 <= v1) or (v3 <= v2 and v2 <= v1):
        s1 = v2
        s2 = v3
    else:
        s1 = v1
        s2 = v3

    avg = (s1 + s2) / 2
    return avg


def pocket(num):
    """
    -------------------------------------------------------
    Determines and returns the colour of numbered roulette wheel
    pocket.
    Use: colour = pocket(num)
    -------------------------------------------------------
    Parameters:
        num - a roulette wheel pocket number (0 <= int <= 36)
    Returns:
        colour - the colour of pocket num (str)
    -------------------------------------------------------
    """
    if num == 0:
        colour = "green"
    elif (num >= 1 and num <= 10) or (num >= 19 and num <= 28):
        if num % 2 == 0:
            # Even numbered pockets
            colour = "black"
        else:
            colour = "red"
    elif (num >= 11 and num <= 18) or (num >= 29 and num <= 36):
        if num % 2 == 0:
            # Even numbered pockets
            colour = "red"
        else:
            colour = "black"
    else:
        colour = "Error"
    return colour


def mix(c_first, c_second):
    """
    -------------------------------------------------------
    Determines the secondary colour from mixing two primary colours.
    Returns an error if the colour parameter(s) are invalid.
        Mix red and blue: purple
        Mix red and yellow: orange
        Mix blue and yellow: green
    Use: colour = mix(c_first, c_second)
    -------------------------------------------------------
    Parameters:
        c_first - a primary colour (str - one of "red", "blue", "yellow")
        c_second - a primary colour (str - one of "red", "blue", "yellow")
    Returns:
        colour - a secondary colour (str - one of "purple", "orange", "green")
    -------------------------------------------------------
    """
    if (c_first == "red" and c_second == "blue") or (c_first == "blue" and c_second == "red"):
        colour = "purple"
    elif (c_first == "blue" and c_second == "yellow") or (c_first == "yellow" and c_second == "blue"):
        colour = "green"
    elif (c_first == "red" and c_second == "yellow") or (c_first == "yellow" and c_second == "red"):
        colour = "orange"
    else:
        colour = "Error"
    return colour


def perfect_square(num):
    """
    -------------------------------------------------------
    Prints all the perfect squares between 1 and num (exclusive).
    Use: perfect_square(num)
    -------------------------------------------------------
    Parameters:
        num - upper end of range of values to test (int > 0)
    Returns:
        string - a string containing the perfect squares, or
            'Error: you entered a negative number' if num is less than 1
            (str)
    ------------------------------------------------------
    """
    if num < 0:
        string = "Error"
    else:
        string = "1"
        # Track the number that creates a perfect square
        sqr = 2

        for i in range(2, num):
            if sqr * sqr == i:
                string += " {}".format(i)
                # Increment the perfect square number
                sqr += 1
    return string

"""
-------------------------------------------------------
[alri1590_a05]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-03-08"
-------------------------------------------------------
"""
from functions import winner

red, green = winner()
print("\nNumber of red entered:", red)
print("Number of green entered:", green)
if red > green:
    print("red team wins!!!")
elif red < green:
    print("green team wins!!!")
else:
    print("tie")

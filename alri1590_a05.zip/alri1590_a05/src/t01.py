"""
-------------------------------------------------------
[alri1590_a05]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-03-08"
-------------------------------------------------------
"""
from functions import fact

n = int(input("Enter a positive number: "))
print()
if n < 0:
    print("Error: you entered a negative number")
else:
    print(str(n) + "! = " + str(fact(n)))

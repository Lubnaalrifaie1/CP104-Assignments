"""
-------------------------------------------------------
[alri1590_a05]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-03-08"
-------------------------------------------------------
"""
from functions import pattern

n = int(input("Enter a positive integer number: "))
while n < 0:
    n = int(input("Enter a positive integer number: "))
pattern(n)

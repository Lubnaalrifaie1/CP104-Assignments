"""
-------------------------------------------------------
[alri1590_a05]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-03-09"
-------------------------------------------------------
"""
from functions import prime

import functions
n = int(input("Enter a positive integer number: "))
if n < 0:
    print("Error: you entered a negative number")
elif functions.prime(n):
    print(n, "is a prime number")
else:
    print(n, "is not a prime number")

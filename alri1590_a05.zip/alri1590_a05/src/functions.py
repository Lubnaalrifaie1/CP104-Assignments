"""
-------------------------------------------------------
[alri1590_a05]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-03-15"
-------------------------------------------------------
"""


def fact(num):
    """
    ------------------------------------------------
    The factorial of n is the product of all the non-negative integers 
    use: num = factorial of the non-negative integer n
    ------------------------------------------------
    Paramenters:
        num - non nagative number (n >= 0) 
    Returns:
        num - num >= 0
    ----------------------------------------------------
    """
    if num < 0:
        return -1
    elif num == 0:
        return 1
    else:
        return num * fact(num - 1)


def prime(num):
    """
    ------------------------------------------------
    a positive integer greater than 1, which has no other factors except 1 and the
    number itself
    use: enter a number and display the returned value 
    ------------------------------------------------
    Paramenters:
        num -  positive number (n >= 0) 
    Returns:
        num - num > 0 = True
        num - num < 0 = False
    ----------------------------------------------------
    """
    for i in range(2, num):
        if num % i == 0:
            return False
    return num > 1


def pattern(num_rows):
    """
    ------------------------------------------------
    enters a negative
number the program should keep asking for positive number until the user enters one
    use: enter a number and displays the output.
    ------------------------------------------------
    Paramenters:
        num_rows - positive number (n >= 0) 
    Returns:
    ----------------------------------------------------
    """
    for i in range(8):
        print("#", end="")
        print(" " * i, end="")
        print("#")
    return


def winner():
    """
    ------------------------------------------------
    The factorial of n is the product of all the non-negative integers 
    use: enter a series of strings
         enter an empty string "" to signal the end of the series
    ------------------------------------------------
    Paramenters:

    Returns:
        num_1
        num_2
    ----------------------------------------------------
    """
    red, green = 0, 0
    while True:
        team = input("Enter the winning team: ")
        if team == 'red':
            red += 1
        elif team == 'green':
            green += 1
        elif team == '':
            break
    return red, green

"""
-------------------------------------------------------
Assignment 9 Functions
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-04-12"
-------------------------------------------------------
"""


def add_2d(matrix1, matrix2):
    """
    -------------------------------------------------------
    Adds the contents of two 2D matrices. The two matrices must
    be of the same size.
    Use: matrix_sum = add_2d(matrix1, matrix2)
    -------------------------------------------------------
    Parameters:
        matrix1 - a 2D matrix (list of lists)
        matrix1 - another 2D matrix (list of lists)
    Returns:
        matrix_sum - the sum or matrix1 and matrix2 (list of list)
    -------------------------------------------------------
    """
    matrix_sum = []

    for row in range(len(matrix1)):
        temp = []

        for col in range(len(matrix1[0])):
            temp.append(matrix1[row][col] + matrix2[row][col])
        matrix_sum.append(temp)
    return matrix_sum


def largest_odd(matrix):
    """
    -------------------------------------------------------
    Finds and returns the largest odd number in matrix in a list.
    Returns [] if no odd number in matrix.
    Use: large_odd = largest_odd(matrix)
    -------------------------------------------------------
    Parameters:
        matrix - a 2D matrix (list of lists of int)
    Returns:
        results - a list of the the largest odd value in matrix,
            an empty list if no odd values found (list of int)
    -------------------------------------------------------
    """
    large_odd = 0

    for row in matrix:
        for col in row:
            if col % 2 != 0 and col > large_odd:
                large_odd = col
    if large_odd > 0:
        results = [large_odd]
    else:
        results = []
    return results


def flatten(a):
    """
    -------------------------------------------------------
    Flatten the contents of 2D list a. A 'flattened' list is a
    2D list that is converted into a 1D list.
    a must be unchanged.
    Use: b = flatten(a):
    -------------------------------------------------------
    Parameters:
        a - a 2D list (2D list of ?)
    Returns:
        b - the flattened version of a (list of ?)
    -------------------------------------------------------
    """
    b = []

    for row in a:
        for col in row:
            b.append(col)
    return b

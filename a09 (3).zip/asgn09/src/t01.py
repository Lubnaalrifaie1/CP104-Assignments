"""
-------------------------------------------------------
Assignment 9, Task 1
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-04-12"
-------------------------------------------------------
"""
# Imports
from functions import add_2d

# get numbers from keyboard
snumbers = input("Enter 12 numbers: ")
numlist = snumbers.split()

matrix1 = [[], [], []]
matrix2 = [[], [], []]

for i in range(2):
    matrix1[0].append(int(numlist[i]))
for i in range(2, 4):
    matrix1[1].append(int(numlist[i]))
for i in range(4, 6):
    matrix1[2].append(int(numlist[i]))
for i in range(6, 8):
    matrix2[0].append(int(numlist[i]))
for i in range(8, 10):
    matrix2[1].append(int(numlist[i]))
for i in range(10, 12):
    matrix2[2].append(int(numlist[i]))

totals = add_2d(matrix1, matrix2)

# Outputs
print("Matrix 1:")
print(matrix1)
print("Matrix 2:")
print(matrix2)
print("Total:")
print(totals)

"""
-------------------------------------------------------
Assignment 9, Task 3
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-04-12"
-------------------------------------------------------
"""
# Imports
from functions import flatten


matrix = [["cat", "dog"], ["emu", "pig"], ["ant", "cow"]]
flat = flatten(matrix)
# Output
print("Matrix:")
print(matrix)
print("FLattened:")
print(flat)

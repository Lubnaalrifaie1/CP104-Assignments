"""
-------------------------------------------------------
Assignment 9, Task 2
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-04-12"
-------------------------------------------------------
"""
# Imports
from functions import largest_odd

matrix = [[8, 10, 12], [14, 16, 18]]
lo = largest_odd(matrix)
print("Source:")
print(matrix)
print("Largest Odd values:")
print(lo)
print("-------------------")
matrix = [[2, 4, 6], [10, 8, 6]]
lo = largest_odd(matrix)
print("Source:")
print(matrix)
print("Largest Odd values:")
print(lo)
print("-------------------")
matrix = [[2, 8, 9], [2, 4, 11]]
lo = largest_odd(matrix)
print("Source:")
print(matrix)
print("Largest Odd values:")
print(lo)
print("-------------------")

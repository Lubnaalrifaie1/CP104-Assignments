"""
-------------------------------------------------------
[alri1590_a09]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-04-12"
-------------------------------------------------------
"""


def add_2d(matrix_a, matrix_b):
    """
    -------------------------------------------------------
    take two 2d-lists of numbers as parameters and returns their
    sum(a matrix/2d-list). Here is an example of how to add two 2d-lists/matrices:
    Use: take two 2d-lists of numbers as paramet
    -------------------------------------------------------
    Parameters:
        n - 12 numbers on one line (n>0)
    Returns:
        m - 13 count on two sentence (m>1)
    ------------------------------------------------------
    """
    sum = [[0, 0], [0, 0], [0, 0]]

    for row in range(len(matrix_a)):
        for col in range(len(matrix_a[0])):
            sum[row][col] = matrix_a[row][col] + matrix_b[row][col]

    return sum


def largest_odd(data):
    """
    -------------------------------------------------------
    that takes a 2d-list of integers as a parameter and returns
    the maximum odd value for the entire list. 
    Use: that takes a 2d-list of integers as a parameter and returns 
    -------------------------------------------------------
    Parameters:
        data - could return a list with that (data>0)
    Returns:
        m - 3 different 2d-lists hardcoded  (m>1)
    ------------------------------------------------------
    """
    result = None
    for x in data:
        for y in x:
            if result == None or (y % 2 != 0 and result < y):
                result = y
    if result == None:
        maximum_odd = []
    else:
        maximum_odd = [result]
    return maximum_odd


def flatten(list_items):
    """
    -------------------------------------------------------
    takes a 2D list and returns all the items of each list concatenated
    together into one new 1D list.
    Use: takes a 2D list and returns all the items of each list concatenated
    -------------------------------------------------------
    Parameters:
        list_items - with a different lists (list_items>0)
    Returns:
        result_list - a PyDev library module (result_list>1)
    ------------------------------------------------------
    """
    result_list = []
    for item in list_items:
        result_list.extend(item)
    return result_list

"""
-------------------------------------------------------
[alri1590_a09]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-04-12"
-------------------------------------------------------
"""
from functions import add_2d

matrix_a = [[0, 0], [0, 0], [0, 0]]
matrix_b = [[0, 0], [0, 0], [0, 0]]


numbers = input("Enter your 12 numbers\n")

l = numbers.split(" ")
i = 0


for row in range(len(matrix_a)):
    for col in range(len(matrix_a[0])):
        matrix_a[row][col] = int(l[i])
        i = i + 1


for row in range(len(matrix_b)):
    for col in range(len(matrix_b[0])):
        matrix_b[row][col] = int(l[i])
        i = i + 1

matrixsum = add_2d(matrix_a, matrix_b)


for row in range(len(matrixsum)):
    for col in range(len(matrixsum[0])):
        print(matrixsum[row][col], end='\t')
    print()

"""
-------------------------------------------------------
[alri1590_a09]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-04-12"
-------------------------------------------------------
"""
from functions import largest_odd

print(largest_odd([[]]))

print(largest_odd([]))

print(largest_odd([[1, 2, 3], [5, 3, 2]]))

"""
-------------------------------------------------------
[alri1590_a05]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-03-21"
-------------------------------------------------------
"""

lst = []


def keep_positive():
    """
    ------------------------------------------------
    Returns a list of numbers where only the positive numbers are kept.
    Use: n = Enter a positive number (n>0)
    -------------------------------------------------
    Parameter:

    Returns:
      result - list of positive number
    ----------------------------------------------------
    """
    n = int(input("Enter a positive number: "))
    while n is not 0:
        if n > 0:
            lst.append(n)
        n = int(input("Enter a positive number: "))
    print("List entered:", lst)
    return lst


def target_loc(numbersList, target):
    """
    -------------------------------------------------------
    Returns a list of indexes in numbersList where target is found
    Use: function to take numbersList and target as parameters
    -------------------------------------------------------
    Parameters:
        numbersList - numbers list (numberslist > 0)
        target - a list of numbers (target > 0)
    Returns:
        targetIndexes - the list of the locations of targeted number
    ------------------------------------------------------
    """
    targetIndexes = []

    for i, x in enumerate(numbersList):
        if x == target:
            targetIndexes.append(i)
    return targetIndexes


def largest_even():
    """
    -------------------------------------------------------
    takes a list of integers as a parameter. If the list
    has no even integers, your function should return -1
    Use: it should return the largest positive even integer in the list.
    -------------------------------------------------------
    Parameters:
        list of integers- list of numbers (n>0)

    Returns:
        the largest positive even integer in the list
    ------------------------------------------------------
    """

    numbersList = []
    keep_positive()

    for i in lst:
        if i % 2 == 0:
            numbersList.append(i)

    if numbersList:
        numbersList.sort()
        print("Largest even:", numbersList[-1])
    else:
        print(-1)
    return


def reverse_list(lst):
    """
    -------------------------------------------------------
    takes a list as a parameter and mutate it such that
    all the elements in the list are reversed
    Use: to get a list of positive numbers
    -------------------------------------------------------
    Parameters:
        lst - positive numbers (lst>0)
    Returns:
        res - list of numbers
    ------------------------------------------------------
    """

    res = []
    for i in range(len(lst) - 1, -1, -1):
        res.append(lst[i])
    return res


def main():
    lst = keep_positive()
    reverse_lst = reverse_list(lst)
    print("List entered: ", lst)
    print("List reversed: ", reverse_lst)

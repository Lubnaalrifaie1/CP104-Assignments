"""
-------------------------------------------------------
[alri1590_a05]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-03-21"
-------------------------------------------------------
"""
from functions import *


if __name__ == '__main__':

    numbersList = keep_positive()

    print('List entered:', numbersList)
    target = int(input("target: "))

    print('target exists at location', target_loc(numbersList, target))

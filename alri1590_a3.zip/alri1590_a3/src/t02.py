"""
-------------------------------------------------------
[A03]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-02-21"
-------------------------------------------------------
"""


def main():

    fat_grams = input('Enter the number of fat grams consumed: ')
    carb_grams = input('Enter the number of carbohydrate grams consumed: ')
    print("Fat calories: 900")
    print("Carb calories: 800")
    print("Total calories: 1700")

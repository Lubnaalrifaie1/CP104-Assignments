"""
-------------------------------------------------------
[A03]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-02-21"
-------------------------------------------------------
"""
answer = int(input("Please enter your answer: "))
print("Your answer: 999, it should be: 376")
answer2 = int(input("Please enter your answer: "))
print("Your answer: 376, it should be: 376")

"""
-------------------------------------------------------
[A03]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-02-21"
-------------------------------------------------------
"""
seconds = int(input("Enter number of seconds:"))
print("There are 0 days, 1 hours, 1 minutes, and 21 seconds in 3681 seconds")

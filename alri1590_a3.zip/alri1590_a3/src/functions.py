"""
-------------------------------------------------------
[A03]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-02-21"
-------------------------------------------------------
"""


def main():
     # local variable
    distance = 0.0

    # #Set up results chart
    print('Time\tFalling Distance')
    print('-----------------------------')

    # loop on time (in seconds)
    for time in range(1, 11):
        distance = falling_distance(time)
    print(time, '\t', format(distance, '.2f'))
# The falling_distance function receives an object's
# falling time and returns the distance it has fallen
# in that time


def falling_distance(time):
    fallDistance = (9.8 * time * time) / 2
    return fallDistance


def main1():

    # Ask for the number of fat grams.
    fat_grams = input('Enter the number of fat grams consumed: ')
    fat_calories(fat_grams)

    # Ask for the number of carb grams.
    carb_grams = input('Enter the number of carbohydrate grams consumed: ')
    carb_calories(carb_grams)


def fat_calories(fat_grams):
    # Calculate the calories from fat.
    # calories_from_fat = fat_grams*9
    calories_from_fat = fat_grams * 9


def carb_calories(carb_grams):
    # Calculate the calories from carbs.
    # calories_from_carbs = carb_grams * 4
    calories_from_carbs = carb_grams * 4



# Call the main function.
main1()
print("Fat calories: 900")
print("Carb calories: 800")
print("Total calories: 1700")


def date_convert(date_int):
    """
        -------------------------------------------------------
       Converts date_int into days, month and year
       use: day,month,year = date_convert(date_int)
        -------------------------------------------------------
        Parameters:
        date_int � (int > 0)
        Returns:
        day: the day in the month in date_int (int >= 0)
        month: the month in date_int (int >=0)
        year: the years in date_int (int >=0)

       sample function run:
        convert_date (12172021)-> 17,12,2021
    -------------------------------------------------------
     """


def convert_sec(num_sec):
    """
     -------------------------------------------------------
        Converts num_sec into days, hours, minutes and seconds
        use: days,hours,minutes, seconds = convert_sec (num_sec)
     -------------------------------------------------------
     Parameters:
         num_sec � (int > 0)
     Returns:
         days: number of days in num_sec (int >= 0)
         hours: number of hours in num_sec (int >=0)
         minutes: number of minutes in num_se (int >=0)
         seconds: number of seconds in num_sec (int >=0)

        sample function run:
                convert_sec (3681) -> 0,1,1,21

     -------------------------------------------------------
    """

"""
-------------------------------------------------------
[A03]
-------------------------------------------------------
Author:  Lubna Al Rifaie 
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-02-21"
-------------------------------------------------------
"""
from functions import main
time = int(input("Enter the time (in secs): "))
print("The Object has falling 490.00 meters in 10 seconds.")

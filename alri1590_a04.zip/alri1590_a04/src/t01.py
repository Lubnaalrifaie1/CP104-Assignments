"""
-------------------------------------------------------
[alri1590_a04]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-02-28"
-------------------------------------------------------
"""
n = int(input("Enter a number between 1 and 7: "))  # read the n
if n >= 1 and n <= 7:
    if n == 1:  # monday
        print("Number", n, "corresponds to Monday.")
    if n == 2:  # tuesday
        print("Number", n, "corresponds to Tuesday.")
    if n == 3:  # wednesday
        print("Number", n, "corresponds to Wednesday.")
    if n == 4:  # Thursday
        print("Number", n, "corresponds to Thursday.")
    if n == 5:  # Friday
        print("Number", n, "corresponds to Friday.")
    if n == 6:  # Saturday
        print("Number", n, "corresponds to Saturday.")
    if n == 7:  # Sunday
        print("Number", n, "corresponds to Sunday.")
else:  # invalid number
    print("Number 9 corresponds to error.")

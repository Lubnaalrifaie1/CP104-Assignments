"""
-------------------------------------------------------
[alri1590_a04]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-03-01"
-------------------------------------------------------
"""

n = int(input("Please enter a number between 1 and 7: "))  # read the n
if n >= 1 and n <= 7:
    if n == 1:  # monday
        print("The number", n, "corresponds to Monday.")
    if n == 2:  # tuesday
        print("The number", n, "corresponds to Tuesday.")
    if n == 3:  # wednesday
        print("The number", n, "corresponds to Wednesday.")
    if n == 4:  # Thursday
        print("The number", n, "corresponds to Thursday.")
    if n == 5:  # Friday
        print("The number", n, "corresponds to Friday.")
    if n == 6:  # Saturday
        print("The number", n, "corresponds to Saturday.")
    if n == 7:  # Sunday
        print("The number", n, "corresponds to Sunday.")
else:  # invalid number
    print("Sorry, that is not a valid number.")


num = int(input('Enter a pocket number: '))
if num == 0:
    col = 'green'
elif num >= 1 and num <= 10:
    if num % 2 == 0:
        col = 'black'
    else:
        col = 'red'
elif num >= 11 and num <= 18:
    if num % 2 == 0:
        col = 'red'
    else:
        col = 'black'
elif num >= 19 and num <= 28:
    if num % 2 == 0:
        col = 'black'
    else:
        col = 'red'
elif num >= 29 and num <= 36:
    if num % 2 == 0:
        col = 'red'
    else:
        col = 'black'

if num < 0 or num > 36:
    print('Error!! Entered number is outside the range of 0 through 36')
else:
    print('The selected pocket is', col)


primary_color1 = input("Enter primary color:")
primary_color2 = input("Enter primary color:")

if (primary_color1 == "red" and primary_color2 == "blue") or (primary_color1 == "blue" and primary_color2 == "red"):
    print("The mixed color is purple.")

elif (primary_color1 == "blue" and primary_color2 == "yellow") or (primary_color1 == "yellow" and primary_color2 == "blue"):
    print("The mixed color is green.")

elif (primary_color1 == "yellow" and primary_color2 == "red") or (primary_color1 == "red" and primary_color2 == "yellow"):
    print("The mixed color is orange.")

else:
    print("You didn't input two primary colors.")


def perfect_square(num):
    if(num > 0):
        i = 2
        print("Perfect Squares below", num, "are: 1", end='')
        while(i * i < num):
            print(", " + str(i * i), end='')
            i += 1
    else:
        print("Invalid input")

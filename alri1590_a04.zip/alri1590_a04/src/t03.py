"""
-------------------------------------------------------
[alri1590_a04]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-02-28"
-------------------------------------------------------
"""
num = int(input('Enter a pocket number: '))
if num == 0:
    col = 'green'
elif num >= 1 and num <= 10:
    if num % 2 == 0:
        col = 'black'
    else:
        col = 'red'
elif num >= 11 and num <= 18:
    if num % 2 == 0:
        col = 'red'
    else:
        col = 'black'
elif num >= 19 and num <= 28:
    if num % 2 == 0:
        col = 'black'
    else:
        col = 'red'
elif num >= 29 and num <= 36:
    if num % 2 == 0:
        col = 'red'
    else:
        col = 'black'

if num < 0 or num > 36:
    print('Error!! Entered number is outside the range of 0 through 36')
else:
    print('The selected pocket is', col)

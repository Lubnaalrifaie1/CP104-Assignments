"""
-------------------------------------------------------
[alri1590_a04]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-02-28"
-------------------------------------------------------
"""
primary_color1 = input("Enter primary color:")
primary_color2 = input("Enter primary color:")

if (primary_color1 == "red" and primary_color2 == "blue") or (primary_color1 == "blue" and primary_color2 == "red"):
    print("The mixed color is purple.")

elif (primary_color1 == "blue" and primary_color2 == "yellow") or (primary_color1 == "yellow" and primary_color2 == "blue"):
    print("The mixed color is green.")

elif (primary_color1 == "yellow" and primary_color2 == "red") or (primary_color1 == "red" and primary_color2 == "yellow"):
    print("The mixed color is orange.")

else:
    print("Error: invalid color mix")

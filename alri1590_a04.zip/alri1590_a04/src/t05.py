"""
-------------------------------------------------------
[alri1590_a04]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-03-01"
-------------------------------------------------------
"""


def perfect_square(num):
    if(num > 0):
        i = 2
        print("Perfect Squares below", num, "are: 1", end='')
        while(i * i < num):
            print(", " + str(i * i), end='')
            i += 1
    else:
        print("Invalid input")


def main():
    num = int(input("Enter a positive integer: "))
    perfect_square(num)


main()

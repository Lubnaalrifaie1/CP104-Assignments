"""
-------------------------------------------------------
Assignment 6, Task 1
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-03-15"
-------------------------------------------------------
"""
# Imports
from functions import keep_positive

numbers = keep_positive()
print()
print("List entered: {}".format(numbers))

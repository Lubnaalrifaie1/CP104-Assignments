"""
-------------------------------------------------------
Assignment 6 Functions
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-03-15"
-------------------------------------------------------
"""


def keep_positive():
    """
    -------------------------------------------------------
    Gets a list of positive numbers from a user.
    Negative numbers are ignored.
    User must enter 0 to stop entries.
    Use: numbers = keep_positive()
    -------------------------------------------------------
    Returns:
        numbers - A list of positive integers (list of int)
    ------------------------------------------------------
    """
    numbers = []
    value = int(input("Enter a positive number: "))

    while value != 0:
        if value > 0:
            numbers.append(value)
        value = int(input("Enter a positive number: "))
    return numbers


def target_loc(num_list, target):
    """
    -------------------------------------------------------
    Finds the locations of targets in num_list.
    Use: locations = target_loc(num_list, target)
    -------------------------------------------------------
    Parameters:
        num_list - list of numbers (list of int)
        target - value to look for in num_list (int)
    Returns:
        locations - list of indexes of target (list of int)
    -------------------------------------------------------
    """
    locations = []

    for i in range(len(num_list)):
        if num_list[i] == target:
            locations.append(i)
    return locations


def largest_even(num_list):
    """
    -------------------------------------------------------
    Finds largest even number in a list. Returns -1 if no
    even numbers.
    Use: largest = largest_even(num_list)
    -------------------------------------------------------
    Parameters:
        num_list - a list of integers (list of int)
    Returns:
        largest - largest even number in num_list (int)
    ------------------------------------------------------
    """
    largest = -1

    for i in range(len(num_list)):
        if num_list[i] % 2 == 0 and num_list[i] > largest:
            largest = num_list[i]
    return largest


def reverse_list(values):
    """
    -------------------------------------------------------
    Reverses the contents of a list in place.
    Use: reverse_list(values)
    -------------------------------------------------------
    Parameters:
        values - a list of values (list of ?)
    Returns:
        None
    ------------------------------------------------------
    """
    n = len(values)
    mid = n // 2

    for i in range(mid):
        temp = values[i]
        values[i] = values[n - i - 1]
        values[n - i - 1] = temp
    return

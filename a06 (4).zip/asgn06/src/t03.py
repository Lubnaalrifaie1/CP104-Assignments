"""
-------------------------------------------------------
Assignment 6, Task 3
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-03-15"
-------------------------------------------------------
"""
# Imports
from functions import keep_positive, largest_even

numbers = keep_positive()
print()
print("List entered: {}".format(numbers))
print()
lo = largest_even(numbers)
print("Largest odd:  {}".format(lo))

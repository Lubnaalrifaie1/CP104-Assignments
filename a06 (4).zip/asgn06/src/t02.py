"""
-------------------------------------------------------
Assignment 6, Task 2
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-03-15"
-------------------------------------------------------
"""
# Imports
from functions import keep_positive, target_loc

numbers = keep_positive()
print()
print("List entered: {}".format(numbers))
print()
target = int(input("Enter target = "))
print()
locations = target_loc(numbers, target)
print("Target exists at location: {}".format(locations))

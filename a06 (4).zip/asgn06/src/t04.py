"""
-------------------------------------------------------
Assignment 6, Task 4
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-03-15"
-------------------------------------------------------
"""
# Imports
from functions import keep_positive, reverse_list

values = keep_positive()
print("List entered: {}".format(values))
reverse_list(values)
print("List reversed: {}".format(values))
print()
values = keep_positive()
print("List entered: {}".format(values))
reverse_list(values)
print("List reversed: {}".format(values))
print()

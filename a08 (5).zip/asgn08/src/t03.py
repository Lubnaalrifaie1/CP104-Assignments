"""
-------------------------------------------------------
Assignment 8, Task 3
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2020-11-24"
-------------------------------------------------------
"""
# Imports
from functions import file_analysis

in_name = input("Enter the input filename: ")
out_name = input("Enter the output filename: ")
fv_in = open(in_name, "r")
fv_out = open(out_name, "w")
print("Processing file:")
upper, lower, digits, whitespace = file_analysis(fv_in)
print("{},{},{},{}".format(upper, lower, digits, whitespace), file=fv_out)
fv_in.close()
fv_out.close()
print("Done")

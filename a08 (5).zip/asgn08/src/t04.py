"""
-------------------------------------------------------
Assignment 8, Task 4
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2020-07-15"
-------------------------------------------------------
"""
# Imports
from functions import valid_sn_file

in_name = input("Enter the input filename: ")
valid_name = input("Enter the valid SN output filename: ")
invalid_name = input("Enter the invalid SN output filename: ")
fv_in = open(in_name, "r")
valid_sns = open(valid_name, "w")
invalid_sns = open(invalid_name, "w")
print("Validating serial numbers")
valid_sn_file(fv_in, valid_sns, invalid_sns)
fv_in.close()
valid_sns.close()
invalid_sns.close()
print("Done")

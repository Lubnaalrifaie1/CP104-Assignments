"""
-------------------------------------------------------
Assignment 8, Task 1
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2020-11-24"
-------------------------------------------------------
"""
# Imports
from functions import total_nums

in_name = input("Enter the input filename: ")
out_name = input("Enter the output filename: ")
fv_in = open(in_name, "r")
fv_out = open(out_name, "w")
print("Processing file:")
numbers, total = total_nums(fv_in)
print("Numbers: {}".format(numbers), file=fv_out)
print("Total: {}".format(total), file=fv_out)
fv_in.close()
fv_out.close()
print("Done")

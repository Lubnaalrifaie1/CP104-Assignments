"""
-------------------------------------------------------
Assignment 8 Functions
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2021-03-29"
-------------------------------------------------------
"""


def total(fh):
    """
    -------------------------------------------------------
    Extracts numbers from a file. Only number surrounded by spaces
    are counted - numbers that are parts of words are ignored.
    Use: numbers = total(fh)
    -------------------------------------------------------
    Parameters:
        fh - a file already open for reading (file handle)
    Returns:
        numbers - a list of integers from fh (list of int)
    -------------------------------------------------------
    """
    numbers = []

    for line in fh:
        words = line.split()

        for word in words:
            if word.isdigit():
                number = int(word)
                numbers.append(number)
    return numbers


def median(fh):
    """
    -------------------------------------------------------
    Extracts numbers from a file and calculates their median value.
    Use: result = median(fh)
    -------------------------------------------------------
    Parameters:
        fh - a file already open for reading (file handle)
    Returns:
        result - median of the values in fh (float)
    -------------------------------------------------------
    """
    numbers = []

    for line in fh:
        words = line.split(',')

        for word in words:
            numbers.append(int(word))
    numbers.sort()
    mid = len(numbers) // 2

    if len(numbers) % 2 == 0:
        result = (numbers[mid - 1] + numbers[mid]) / 2
    else:
        result = numbers[mid]
    return result


def file_stats(file_in):
    """
    -------------------------------------------------------
    Evaluates the contents of a file.
    Use: ucount, lcount, dcount, wcount = file_stats(file_in)
    -------------------------------------------------------
    Parameters:
        file_in - a file already open for reading (file handle)
    Returns:
        ucount - The number of uppercase letters in the file (int)
        lcount - The number of lowercase letters in the file (int)
        dcount - The number of digits in the file (int)
        wcount - The number of whitespace characters in the file (int)
    -------------------------------------------------------
    """
    ucount = 0
    lcount = 0
    dcount = 0
    wcount = 0

    for line in file_in:
        for char in line:
            if char.isdigit():
                dcount += 1
            elif char.isspace():
                wcount += 1
            elif char.isupper():
                ucount += 1
            elif char.islower():
                lcount += 1
    return ucount, lcount, dcount, wcount


def valid(sn):
    """
    -------------------------------------------------------
    Determines if a string is a good serial number. Good serial
    numbers are of the form 'SN/nnnn-nnn', where 'n' is a digit.
    Use: is_valid = valid(sn)
    -------------------------------------------------------
    Parameters:
        sn - a possible serial number (str)
    Returns:
        is_valid - True if sn is a good serial number,
            False otherwise (boolean)
    -------------------------------------------------------
    """
    if len(sn) == 11 and sn.startswith('SN/') and sn[7] == '-' and \
            sn[3:7].isdigit() and sn[8:].isdigit():
        is_valid = True
    else:
        is_valid = False
    return is_valid


def valid_file(file_in, good_sns, bad_sns):
    """
    -------------------------------------------------------
    Evaluates serial numbers from a file. Writes valid serial
    numbers to good_sns, and invalid serial numbers to bad_sns.
    Use: valid_file(file_in, good_sns, bad_sns)
    -------------------------------------------------------
    Parameters:
        file_in - a file already open for reading (file handle)
        good_sns - a file already open for writing (file handle)
        bad_sns - a file already open for writing (file handle)
    Returns:
        None
    -------------------------------------------------------
    """
    for line in file_in:
        line = line.strip()

        if valid(line):
            print(line, file=good_sns)
        else:
            print(line, file=bad_sns)
    return

"""
-------------------------------------------------------
Assignment 8, Task 2
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2020-11-24"
-------------------------------------------------------
"""
# Imports
from functions import locate_median

in_name = input("Enter the input filename: ")
out_name = input("Enter the output filename: ")
fv_in = open(in_name, "r")
fv_out = open(out_name, "w")
print("Processing file:")
median = locate_median(fv_in)
print("Median: {}".format(median), file=fv_out)
fv_in.close()
fv_out.close()
print("Done")

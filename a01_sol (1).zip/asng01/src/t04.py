"""
------------------------------------------------------------------------
 inches -> meters
------------------------------------------------------------------------
Author: Safaa Bedawi
ID:     11111111
Email:  sbedawi@wlu.ca
__updated__ = "2020-04-20"
------------------------------------------------------------------------
"""
# Constants
INCH_TO_METRES = 0.0254

# Inputs
inches = float(input("Enter the height in inches: "))

# Processing
metres = INCH_TO_METRES * inches

# Output
print("The equivalent height is in meters is {:.2f}".format(metres))
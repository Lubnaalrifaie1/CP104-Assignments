"""
------------------------------------------------------------------------
calculate balance
------------------------------------------------------------------------
Author: Safaa Bedawi
ID:     11111111
Email:  sbedawi@wlu.ca
__updated__ = "2020-04-20"
------------------------------------------------------------------------
"""
#Input
principal_p = float(input("Principal: "))
interest_r = float(input("Interest (decimal): "))
year_t = int(input("Number of years: "))
comp_year_n = int(input("Compound interest per year: "))

# Processing
balance = principal_p * (1 + interest_r / comp_year_n)**(comp_year_n * year_t)


# Output
print()
print("Balance: $ {:.2f}".format(balance))

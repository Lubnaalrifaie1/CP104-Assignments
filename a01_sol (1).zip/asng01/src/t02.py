"""
------------------------------------------------------------------------
Display name and eye colour
------------------------------------------------------------------------
Author: Safaa Bedawi
ID:     11111111
Email:  sbedawi@wlu.ca
__updated__ = "2020-04-20"
------------------------------------------------------------------------
"""
# Input
name = input("What is your name? ")
colour = input("What is your eye colour? ")

# Output
print()
print("My name is", name, "and I have", colour, "eyes")
# or
# print("My name is {} and I have {} eyes".format(name, colour))

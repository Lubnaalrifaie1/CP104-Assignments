"""
------------------------------------------------------------------------
 welcome message
------------------------------------------------------------------------
Author: Safaa Bedawi
ID:     11111111
Email:  sbedawi@wlu.ca
__updated__ = "2020-04-20"
------------------------------------------------------------------------
"""
# Input
last = input("What is last name? ")
first = input("What is first name? ")

# Output
print("Welcome", first, last)
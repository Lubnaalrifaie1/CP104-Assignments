"""
------------------------------------------------------------------------
Displaying strings
------------------------------------------------------------------------
Author: Safaa Bedawi
ID:     11111111
Email:  sbedawi@wlu.ca
__updated__ = "2020-04-20"
------------------------------------------------------------------------
"""

# Output
print('The book title is, "Learn Python in 21 Days".')
print("What's mine is mine, and what's yours is mine.")
print(""""You have enemies? Good. That means you've stood up for something, sometime in your life." Winston Churchill""")
print('''Three things cannot be long hidden:
the sun,
the moon,
and the truth.''')

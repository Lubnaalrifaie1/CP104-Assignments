"""
-------------------------------------------------------
[alri1590_a07]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-03-22"
-------------------------------------------------------
"""
from functions import proper_spaces

my_str = input("Enter a string :")
new_str = proper_spaces(my_str)
print(new_str)

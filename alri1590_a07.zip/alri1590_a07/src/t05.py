"""
-------------------------------------------------------
[alri1590_a07]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-03-28"
-------------------------------------------------------
"""
from functions import chain

words = input('Enter list of words separated with spaces: \n')
word_list = words.split()

if chain(word_list):
    print('\nthe List represents a word chain')
else:
    print('\nthe List does not represents a word chain')

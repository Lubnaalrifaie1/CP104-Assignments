"""
-------------------------------------------------------
[alri1590_a07]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-03-28"
-------------------------------------------------------
"""
from functions import frequent

s = input("Enter a string : ")
ch = frequent(s)
print("Most frequent characters:", ch)

"""
-------------------------------------------------------
[alri1590_a07]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-03-28"
-------------------------------------------------------
"""


def vowels_sc(my_str):
    """
    -------------------------------------------------------
    The vowels in the string that is returned are in a different case. In other
    words, if the letter from the original string was a lowercase
    vowel, then the string will contain an upper case vowel
    Use: out += i.swapcase()
    -------------------------------------------------------
    Parameters:
        my_str - should return an empty string
    Returns:
        out - a new string containing only the vowels
    ------------------------------------------------------
    """
    vowels = ["a", "A", "e", "E", "i", "I", "o", "O", "u", "U"]

    out = ""
    for i in my_str:
        if i in vowels:
            out += i.swapcase()
    return out


def str_digit_sum(my_str):
    """
    -------------------------------------------------------
    sums all the single digit numbers in my_str
    use: total = str_digit_sum (my_str)
    -------------------------------------------------------
    Parameters:
        my_str: string that has single-digit numbers (str)
    Returns:
        total: sum of all the single digit number (integer >= 0)
    -------------------------------------------------------
    Sample run
    str_digit_sum ('2501') returns 8

    """
    number = int(my_str)
    total = int(0)
    while number > 0:
        digit = int(number % 10)
        total = total + digit
        number = int(number / 10)
    return total


def frequent(s):
    """
    -------------------------------------------------------
    finds the character that appears most frequently in the
    input parameter string and returns it
    Use: word = frequent(s)
    -------------------------------------------------------
    Parameters:
        s - a string of words
    Returns:
        char - characters or more with the same frequency the function
    ------------------------------------------------------
    """
    L = []
    count = 0
    char = 0
    for i in range(0, len(s), 1):
        x = s[i]
        found = False
        for j in range(len(L)):
            if x == L[j]:
                L[j + 1] = L[j + 1] + 1
                found = True
        else:
            if found == False:
                L.append(x)
                L.append(1)

    for i in range(1, len(L), 2):
        if L[i] > count:
            count = L[i]
            char = L[i - 1]
    return char


def proper_spaces(my_str):
    """
    -------------------------------------------------------
    create a new string with added space between words
    use: new_str = proper_spaces (my_str)
    -------------------------------------------------------
    Parameters:
        my_str: string that represents a sentence in which all the
                words are run together (no spaces), but the first
                character of each word is uppercase.
                my_str should has at least one character (str)

    Returns:
        new_str: new string in which the words are separated
                 by spaces and only the first word starts with
                 an uppercase character.
    -------------------------------------------------------
    Sample run
    proper_spaces('StopAndSmellTheRose.') returns ' Stop and smell the
    roses.'
    """
    new_str = my_str[0]
    for elements in range(1, len(my_str)):
        ch = my_str[elements]
        if ch.isupper():
            new_str = new_str + " " + ch.lower()
        else:
            new_str = new_str + ch
    return new_str


def chain(my_list):
    """
    -------------------------------------------------------
    A word chain is a list of words such that for each consecutive pair of
    words, the last letter
    in the first word is the same as the first letter in the second word.
    Use: word_list = words.split()
    -------------------------------------------------------
    Parameters:
        my_list - a list of words (number of words > 2)
    Returns:
        is_chain - has the same first and last letters
    ------------------------------------------------------
    """
    is_chain = True
    for i in range(len(my_list) - 1):
        if my_list[i][len(my_list[i]) - 1] != my_list[i + 1][0]:
            is_chain = False

    return is_chain

"""
-------------------------------------------------------
[alri1590_a07]
-------------------------------------------------------
Author:  Lubna Al Rifaie
ID:      200821590
Email:   alri1590@mylaurier.ca
__updated__ = "2021-03-25"
-------------------------------------------------------
"""
from functions import vowels_sc

my_str = input("Please enter a sentence: ")


print("Vowels in your input: ", vowels_sc(my_str))
